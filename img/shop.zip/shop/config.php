<?php

$dbServername = 'localhost';
$dbUsername = 'root';
$dbPassword = 'honeywell';
$dbName = 'shop';

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
