<?php
	include("config.php");
?>
<!DOCTYPE html>
<html lang="zxx" class="no-js">

<head>
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Favicon-->
	<link rel="shortcut icon" href="img/fav.png">
	<!-- Author Meta -->
	<meta name="author" content="Adetinji Oluwaferanmi">
	<!-- Meta Description -->
	<meta name="description" content="The one shop for all your needs">
	<!-- Meta Keyword -->
	<meta name="keywords" content="smart drops, shop, online market, supermarket, boutique, groceries, smart">
	<!-- meta character set -->
	<meta charset="UTF-8">
	<!-- Site Title -->
	<title>Smart Drops Supermarket</title>
	<!--
		CSS
		============================================= -->
	<link rel="stylesheet" href="css/linearicons.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/themify-icons.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/nice-select.css">
	<link rel="stylesheet" href="css/nouislider.min.css">
	<link rel="stylesheet" href="css/ion.rangeSlider.css" />
	<link rel="stylesheet" href="css/ion.rangeSlider.skinFlat.css" />
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/main.css">
</head>

<body>
	<?php include('header.php');?>
	<!-- start banner Area -->
	<section class="banner-area">
		<div class="container">
			<div class="row fullscreen align-items-center justify-content-start">
				<div class="col-lg-12">
					<div class="active-banner-slider owl-carousel">
						<!-- single-slide -->
						<div class="row single-slide align-items-center d-flex" style="margin: 2% auto;">
            <div class="col-lg-6">
								<div class="banner-content">
									<h1>Smart Drops <br>Supermarket!</h1>
									<p>The One shop for all your needs</p>
								</div>
                <div class="add-bag d-flex align-items-center">
									<a class="add-btn" href="home.php"><span class="lnr lnr-cross"></span></a>
									<span class="add-text text-uppercase">Start Shopping</span>
								</div>
							</div>
              <div class="col-lg-6">
								<div class="banner-img">
									<img class="img-fluid" src="img/sds2.jpeg" style="display:none;width:400px;height:700px;margin-top:15%;">
								</div>
							</div>
						</div>
						<!-- single-slide -->
						<div class="row single-slide">
							<div class="col-lg-5">
								<div class="banner-content">
									<h1>Smart Drops <br>Boutique!</h1>
									<p>The One shop for all your needs</p>
								</div>
                <div class="add-bag d-flex align-items-center">
									<a class="add-btn" href="home.php"><span class="lnr lnr-cross"></span></a>
									<span class="add-text text-uppercase">Start Shopping</span>
								</div>
							</div>
							<div class="col-lg-7" style="display:none;">
								<div class="banner-img">
									<img class="img-fluid" src="img/banner/banner-img.png" alt="">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End banner Area -->

  <!-- start features Area -->
  <?php include('features.php');?>
  <!-- end features Area -->

	<!-- Start category Area -->
	<section class="category-area">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8 col-md-12">
					<div class="row">
						<div class="col-lg-4 col-md-8">
							<div class="single-deal">
								<div class="overlay"></div>
								<img class="img-fluid w-100" style="width:459px;height:220px;" src="img/b15.jpeg" alt="">
								<div class="deal-details">
										<a href="drinks.php"><h6 class="deal-title">Drinks, Wine, Spirits</h6></a>
									</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="single-deal">
								<div class="overlay"></div>
								<img class="img-fluid w-100" style="width:262px;height:225px;" src="img/cosmetics.jpeg" alt="">
								<div class="deal-details">
										<a href="cosmetics.php"><h6 class="deal-title">Cosmetics</h6></a>
									</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="single-deal">
								<div class="overlay"></div>
								<img class="img-fluid w-100" style="width:262px;height:225px;" src="img/gift.jpeg" alt="">
                <div class="deal-details">
										<a href="gifts.php"><h6 class="deal-title">Household & Gift Items</h6></a>
									</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-8">
							<div class="single-deal">
								<div class="overlay"></div>
								<img class="img-fluid w-100" style="width:458px;height:184px;" src="img/boutique.jpeg" alt="">
								<div class="deal-details">
										<a href="boutique.php"><h6 class="deal-title">Boutique</h6></a>
									</div>
							</div>
            </div>
            <div class="col-lg-4 col-md-4">
							<div class="single-deal">
								<div class="overlay"></div>
								<img class="img-fluid w-100" style="width:262px;height:225px;" src="img/con.jpeg" alt="">
                <div class="deal-details">
										<a href="confec.php"><h6 class="deal-title">Confectionery</h6></a>
									</div>
							</div>
            </div>
            <div class="col-lg-4 col-md-4">
							<div class="single-deal">
								<div class="overlay"></div>
								<img class="img-fluid w-100" style="width:262px;height:225px;" src="img/baby.jpeg" alt="">
								<div class="deal-details">
										<a href="baby.php"><h6 class="deal-title">Baby Products</h6></a>
									</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="single-deal">
						<div class="overlay"></div>
						<img class="img-fluid w-100" style="width:360px;height:425px;" src="img/grocery.jpeg" alt="">
						<div class="deal-details">
								<a href="grocery.php"><h6 class="deal-title">Grocery</h6></a>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End category Area -->


	<!-- Start brand Area -->
	<section class="brand-area section_gap">
		<div class="container">
			<div class="row">
				<a class="col single-img" href="#">
					<img class="img-fluid d-block mx-auto" src="img/brand/1.png" alt="">
				</a>
				<a class="col single-img" href="#">
					<img class="img-fluid d-block mx-auto" src="img/brand/2.png" alt="">
				</a>
				<a class="col single-img" href="#">
					<img class="img-fluid d-block mx-auto" src="img/brand/3.png" alt="">
				</a>
				<a class="col single-img" href="#">
					<img class="img-fluid d-block mx-auto" src="img/brand/4.png" alt="">
				</a>
				<a class="col single-img" href="#">
					<img class="img-fluid d-block mx-auto" src="img/brand/5.png" alt="">
				</a>
			</div>
		</div>
	</section>
	<!-- End brand Area -->

	<?php include('footer.php');?>

	<script src="js/vendor/jquery-2.2.4.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery.sticky.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/countdown.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/gmaps.min.js"></script>
	<script src="js/main.js"></script>
</body>

</html>
