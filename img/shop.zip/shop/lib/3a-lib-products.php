<?php
class Products extends DB {
  function getLimit () {
  // get () : get all products
    return $this->fetch(
      "SELECT * FROM `products` ORDER BY `product_id` DESC LIMIT 8", null,
      "product_id"
    );
  }
  function get () {
  // get () : get all products
    return $this->fetch(
      "SELECT * FROM `products` ORDER BY `product_id` DESC", null,
      "product_id"
    );
  }
  function getByCatFood () {
    return $this->fetch(
      "SELECT * FROM `products` WHERE `category`='food'", null,
      "product_id"
    );
  }

  function getByCatBoutique () {
  // get () : get all products by category

    return $this->fetch(
      "SELECT * FROM `products` WHERE `category`='boutique'", null,
      "product_id"
    );
  }

  function getByCatDrinks () {
  // get () : get all products by category

    return $this->fetch(
      "SELECT * FROM `products` WHERE `category`='drinks'", null,
      "product_id"
    );
  }

  function getByCatSnacks () {
  // get () : get all products by category

    return $this->fetch(
      "SELECT * FROM `products` WHERE `category`='snacks'", null,
      "product_id"
    );
  }

  function getByCatEssentials () {
  // get () : get all products by category

    return $this->fetch(
      "SELECT * FROM `products` WHERE `category`='essentials'", null,
      "product_id"
    );
  }

  function add ($name, $img, $desc, $price) {
  // add () : add new product

    return $this->exec(
      "INSERT INTO `products` (`product_name`, `product_image`, `product_description`, `product_price`) VALUES (?, ?, ?, ?)",
      [$name, $img, $desc, $price]
    );
  }

  function edit ($id, $name, $img, $desc, $price) {
  // pEdit () : update product

    return $this->exec(
      "UPDATE `products` SET `product_name`=?, `product_image`=?, `product_description`=?, `product_price`=? WHERE `product_id`=?",
      [$name, $img, $desc, $price, $id]
    );
  }

  function del ($id) {
  // del () : delete product

    return $this->exec(
      "DELETE FROM `products` WHERE `product_id`=?",
      [$id]
    );
  }
}
?>
