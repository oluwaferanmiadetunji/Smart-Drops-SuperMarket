<?php
    if(isset($_POST['submit'])){
        include_once 'config.php';
        $category = mysqli_real_escape_string($conn, $_POST['category']);
        $brand = mysqli_real_escape_string($conn, $_POST['brand']);

        //error handlers
        //check for empty fields
        if(empty($brand) || empty($category) ){
            echo "<script type='text/javascript'>
            alert('Fields Empty!');
            window.location= '../add.brand.php';
            </script>";
            exit();
        } else {
            $sql = "SELECT * FROM brands WHERE brand_name='$brand';";
            $result = mysqli_query($conn, $sql);
            $result_check = mysqli_num_rows($result);
            if ($result_check > 0) {
                echo "<script type='text/javascript'>
                alert('That brand has already been added!');
                window.location= '../brands.php';
                </script>";
                exit();
            } else {
                $sql = "INSERT INTO `brands` (`id`, `brand_name`, `category_name`) VALUES (null, '$brand', '$category');";
                mysqli_query($conn, $sql);
                echo "<script type='text/javascript'>
                alert('Brand added!');
                window.location= '../brands.php';
                </script>";
                exit();
            }
        }
    } else {
        header('Location: ../brands.php');
        exit();
    }
