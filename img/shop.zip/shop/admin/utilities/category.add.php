<?php
    if(isset($_POST['submit'])){
        include_once 'config.php';
        $name = mysqli_real_escape_string($conn, $_POST['name']);

        //error handlers
        //check for empty fields
        if(empty($name) ){
            echo "<script type='text/javascript'>
            alert('Fields Empty!');
            window.location= '../add.category.php';
            </script>";
            exit();
        } else {
            $sql = "SELECT * FROM categories WHERE category_name='$name';";
            $result = mysqli_query($conn, $sql);
            $result_check = mysqli_num_rows($result);
            if ($result_check > 0) {
                echo "<script type='text/javascript'>
                alert('That category has already been added!');
                window.location= '../categories.php';
                </script>";
                exit();
            } else {
                $sql = "INSERT INTO `categories` (`id`, `category_name`) VALUES (null, '$name');";
                mysqli_query($conn, $sql);
                echo "<script type='text/javascript'>
                alert('Category added!');
                window.location= '../categories.php';
                </script>";
                exit();
            }
        }
    } else {
        header('Location: ../categories.php');
        exit();
    }
