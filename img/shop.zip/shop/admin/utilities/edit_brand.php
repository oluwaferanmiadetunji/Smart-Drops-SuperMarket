<?php
    include_once("config.php");

    if (isset($_POST['submit'])) {
        $id = $_POST['id'];
        $brand = mysqli_real_escape_string($conn, $_POST['brand']);
        $category = mysqli_real_escape_string($conn, $_POST['category']);


        if(empty($brand) || empty($category)) {
            echo "<script type='text/javascript'>
            alert('One or more fields are missing!');
            window.location= '../brands.php';
            </script>";
            exit();
        } else {
            $sql ="UPDATE brands SET brand_name='$brand', category_name='$category' WHERE id='$id';";
            mysqli_query($conn, $sql);
            echo "<script type='text/javascript'>
            alert('Brand Updated!');
            window.location= '../brands.php';
            </script>";
            exit();
        }
    } else {
        header('Location: ../brands.php');
        exit();
    }
