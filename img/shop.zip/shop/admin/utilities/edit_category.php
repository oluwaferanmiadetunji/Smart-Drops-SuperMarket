<?php
    include_once("config.php");

    if (isset($_POST['submit'])) {
        $id = $_POST['id'];
        $name = mysqli_real_escape_string($conn, $_POST['name']);


        if(empty($name)) {
            echo "<script type='text/javascript'>
            alert('One or more fields are missing!');
            window.location= '../categories.php';
            </script>";
            exit();
        } else {
            $sql ="UPDATE categories SET category_name='$name' WHERE id='$id';";
            mysqli_query($conn, $sql);
            echo "<script type='text/javascript'>
            alert('Category Updated!');
            window.location= '../categories.php';
            </script>";
            exit();
        }
    } else {
        header('Location: ../categories.php');
        exit();
    }
