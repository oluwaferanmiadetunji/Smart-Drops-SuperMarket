<?php

$month = date('m');
$day = date('d');
$year = date('Y');

$today = $year . '-' . $month . '-' . $day;
?>
<?php
session_start();
if(!isset($_SESSION['email'])){
   header("Location: login.php");
}
// SHOPPING CART WILL BE STORED IN THE SESSION
// $_SESSION['cart'][PRODUCT ID] = QUANTITY
require __DIR__ . DIRECTORY_SEPARATOR . "lib" . DIRECTORY_SEPARATOR . "2a-config.php";
switch ($_POST['req']) {
  /* [INVALID REQUEST] */
  default:
    echo "INVALID REQUEST";
    break;

  /* [ADD ITEM TO CART] */
  case "add":
    if (is_numeric($_SESSION['cart'][$_POST['product_id']])) {
      $_SESSION['cart'][$_POST['product_id']] ++;
    } else {
      $_SESSION['cart'][$_POST['product_id']] = 1;
    }
    echo "Item added to cart";
    break;

  /* [COUNT TOTAL NUMBER OF ITEMS] */
  case "count":
    $total = 0;
    if (count($_SESSION['cart'])>0) {
      foreach ($_SESSION['cart'] as $id => $qty) {
        $total += $qty;
      }
    }
    echo $total;
    break;

  /* [SHOW CART] */
  case "show":
    // Fetch products
    require PATH_LIB . "2b-lib-db.php";
    require PATH_LIB . "4c-lib-cart.php";
    $cartLib = new Cart();
    $products = $cartLib->details();

    // Cart contents in HTML
    $sub = 0;
    $total = 0; ?>
    <!-- Start Banner Area -->
    <section class="banner-area organic-breadcrumb">
        <div class="container">
            <div class="breadcrumb-banner d-flex flex-wrap align-items-center justify-content-end">
                <div class="col-first">
                    <Smart Drops Supermarket Cart</h1>
                    <nav class="d-flex align-items-center">
                        <a href="home.php">Home<span class="lnr lnr-arrow-right"></span></a>
                        <a href="category.php">Cart</a>
                    </nav>
                </div>
            </div>
        </div>
    </section>
    <!-- End Banner Area -->
    <section class="cart_area">
        <div class="container">
            <div class="cart_inner">
                <div class="table-responsive">
                    <table class="table cart_items" id="cart-table">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Price</th>
                                <th scope="col">Remove</th>
                            </tr>
                        </thead>
                        <?php
                        if (count($_SESSION['cart'])>0) {
                        foreach ($_SESSION['cart'] as $id => $qty) {
                          $sub = $qty * $products[$id]['product_price'];
                          $total += $sub; ?>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="media">
                                        <div class="d-flex">
                                            <img src="img/cart.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <p><?= $products[$id]['product_name'] ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="product_count">
                                        <input id="qty_<?= $id ?>" maxlength="12" type="number" onchange='cart.change(<?= $id ?>);' value="<?= $qty ?>" title="Quantity:"
                                            class="input-text qty">
                                    </div>
                                </td>
                                <td>
                                    <h5><?= sprintf("#%0.2f", $sub) ?></h5>
                                </td>
                                <td>
                                    <h5><input class="cart-remove btn btn-danger" style="cursor:pointer;" type="button" value="Delete" onclick="cart.remove(<?= $id ?>);"/></h5>
                                </td>
                            </tr>

                            
                            <?php }?>
                             <tr>
                             <td>

                             </td>
                             <td>

                             </td>
                             <td>
                                 <h5>Subtotal</h5>
                             </td>
                             <td>
                                 <h5><?= sprintf("#%0.2f", $total) ?></h5>
                             </td>
                         </tr>
                         <tr class="shipping_area">
                             <td>

                             </td>
                             <td>

                             </td>
                             <td>
                                 <h5>Shipping</h5>
                             </td>
                             <td>
                                 <div class="shipping_box">
                                     <ul class="list">
                                         <li><a href="#">Flat Rate: $5.00</a></li>
                                         <li><a href="#">Free Shipping</a></li>
                                         <li><a href="#">Flat Rate: $10.00</a></li>
                                         <li class="active"><a href="#">Local Delivery: $2.00</a></li>
                                     </ul>
                                     <h6>Calculate Shipping <i class="fa fa-caret-down" aria-hidden="true"></i></h6>
                                     <select class="shipping_select">
                                         <option value="1">Bangladesh</option>
                                         <option value="2">India</option>
                                         <option value="4">Pakistan</option>
                                     </select>
                                     <select class="shipping_select">
                                         <option value="1">Select a State</option>
                                         <option value="2">Select a State</option>
                                         <option value="4">Select a State</option>
                                     </select>
                                     <input type="text" placeholder="Postcode/Zipcode">
                                     <a class="gray_btn" href="#">Update Details</a>
                                 </div>
                             </td>
                         </tr>
                         <tr class="out_button_area">
                             <td>

                             </td>
                             <td>

                             </td>
                             <td>

                             </td>
                             <td>
                                 <div class="checkout_btn_inner d-flex align-items-center">
                                     <a class="gray_btn" href="home" style="margin-right:20px;">Continue Shopping</a>
                                     <button class="primary-btn" onclick="cart.showCheckOut();">Proceed to checkout</button>
                                 </div>
                             </td>
                         </tr>
                          <?php } else { ?>
                            <tr><td colspan="3">Cart is empty</td></tr>
                            <?php } ?>
                           
                        </tbody>
                    </table>
                    <?php if (count($_SESSION['cart']) > 0) { ?>
                    <div style="margin:10px auto;width:90%;display:none;" id="CheckOut">
                        <form id="cart-checkout" onsubmit="return cart.checkout();">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" id="co_name" required value="<?php echo $_SESSION['name'];?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="co_email" required value="<?php echo $_SESSION['email'];?>">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" style="cursor:pointer;margin-bottom:10px;">Checkout</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php }
    break;

  /* [CHANGE QTY] */
  case "change":
    if ($_POST['qty'] == 0) {
      unset($_SESSION['cart'][$_POST['product_id']]);
    } else {
      $_SESSION['cart'][$_POST['product_id']] = $_POST['qty'];
    }
    echo "Quantity updated";
    break;

  /* [CHECKOUT] */
  // @TODO
  // Beef up this section on your own!
  // There are no error & security checks in this simple example
  // You may also want to add more of your own checkout procedures here
  case "checkout":
    require PATH_LIB . "2b-lib-db.php";
    require PATH_LIB . "4c-lib-cart.php";
    $cartLib = new Cart();
    if ($cartLib->checkout($_POST['name'], $_POST['email'])) {
      $_SESSION['cart'] = [];
      echo "OK";
    } else {
      echo $cartLib->error;
    }
    break;

  /* [ALTERNATIVE CHECKOUT] */
  // This version sends an email to the customer on successful checkout
  case "checkout-email":
    require PATH_LIB . "2b-lib-db.php";
    require PATH_LIB . "4c-lib-cart.php";
    $cartLib = new Cart();
    if ($cartLib->checkout($_POST['name'], $_POST['email'])) {
      $_SESSION['cart'] = [];
      // @TODO
      // Format this email message as you see fit
      $order = $cartLib->get($cartLib->orderID);
      $to = $_POST['email'];
      $subject = "Order Received";
      $message = "";
      foreach ($order['items'] as $pid=>$p) {
        $message .= $p['product_name'] . " - " . $p['quantity'] . "<br>";
      }
      $headers = implode("\r\n", [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=utf-8',
        'From: email@gmail.com'
      ]);
      echo @mail($to, $subject, $message, $headers) ? "OK" : "ERROR sending email!" ;
    } else {
      echo $cartLib->error;
    }
    break;
}
?>
