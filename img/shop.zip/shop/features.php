        
<section class="features-area section_gap">
		<div class="container">
      <h1 class="text-center">Our Areas of Delivery</h1>
			<div class="row features-inner">
				<!-- single features -->
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="single-features">
						<div class="f-icon">
							<img src="img/features/f-icon1.png" alt="">
						</div>
						<h6>Bodija</h6>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="single-features">
						<div class="f-icon">
							<img src="img/features/f-icon1.png" alt="">
						</div>
						<h6>Bodija</h6>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="single-features">
						<div class="f-icon">
							<img src="img/features/f-icon1.png" alt="">
						</div>
						<h6>Bodija</h6>
					</div>
        </div>
        <div class="col-lg-2 col-md-4 col-sm-4">
					<div class="single-features">
						<div class="f-icon">
							<img src="img/features/f-icon1.png" alt="">
						</div>
						<h6>Bodija</h6>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="single-features">
						<div class="f-icon">
							<img src="img/features/f-icon1.png" alt="">
						</div>
						<h6>Bodija</h6>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="single-features">
						<div class="f-icon">
							<img src="img/features/f-icon1.png" alt="">
						</div>
						<h6>Bodija</h6>
					</div>
				</div>
			</div>
		</div>
	</section>
	